﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Введите строку для записи в файл:");
      string text = Console.ReadLine();
      using (FileStream fstream = new FileStream($"C:\\Users\\Luna\\source\\repos\\ConsoleApp2\\ConsoleApp2\\1.txt", FileMode.OpenOrCreate))
      {
        byte[] array = System.Text.Encoding.Default.GetBytes(text);
        fstream.Write(array, 0, array.Length);
        Console.WriteLine("Текст записан в файл");
      }
      using (FileStream fstream = File.OpenRead($"C:\\Users\\Luna\\source\\repos\\ConsoleApp2\\ConsoleApp2\\1.txt"))
      {
        byte[] array = new byte[fstream.Length];
        fstream.Read(array, 0, array.Length);
        string textFromFile = System.Text.Encoding.Default.GetString(array);
        Console.WriteLine($"Текст из файла: {textFromFile}");
      }
      Console.ReadLine();
      int k = 0;
      while (k==0)
      {
        Console.Write("Удалить файл? 1 -да, 0 - нет");
        string text2 = Console.ReadLine();
        if (text2 == "1")
        {
          File.Delete(@"C:\\Users\\Luna\\source\\repos\\ConsoleApp2\\ConsoleApp2\\1.txt");
          k++;
        }
        if (text2 == "0")
        {
          k++;
        }
          if (text2 != "1" && text2 != "0")
        {
          Console.WriteLine("Введен неправильный символ");
        }
      }
    }
  }
}
