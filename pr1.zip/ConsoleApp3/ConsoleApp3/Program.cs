﻿using System;
using System.Text.Json;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp3
{
  class Person
  {
    public string Name { get; set; }
    public int Age { get; set; }
  }
  class Program
  {
    static async Task Main(string[] args)
    {
      using (FileStream fs = new FileStream("C:\\Users\\Luna\\source\\repos\\ConsoleApp3\\ConsoleApp3\\file.json", FileMode.OpenOrCreate))
      {
        Person elena = new Person() { Name = "Elena", Age = 22 };
        await JsonSerializer.SerializeAsync<Person>(fs, elena);
        Console.WriteLine("Данные записаны в файл");
      }
      using (FileStream fs = new FileStream("C:\\Users\\Luna\\source\\repos\\ConsoleApp3\\ConsoleApp3\\file.json", FileMode.OpenOrCreate))
      {
        Person restoredPerson = await JsonSerializer.DeserializeAsync<Person>(fs);
        Console.WriteLine($"Name: {restoredPerson.Name}\nAge: {restoredPerson.Age}");
      }
      int k = 0;
      while (k == 0)
      {
        Console.Write("Удалить файл? 1 -да, 0 - нет");
        string text2 = Console.ReadLine();
        if (text2 == "1")
        {
          File.Delete("C:\\Users\\Luna\\source\\repos\\ConsoleApp3\\ConsoleApp3\\file.json");
          k++;
        }
        if (text2 == "0")
        {
          k++;
        }
        if (text2 != "1" && text2 != "0")
        {
          Console.WriteLine("Введен неправильный символ");
        }
      }
    }
  }
}