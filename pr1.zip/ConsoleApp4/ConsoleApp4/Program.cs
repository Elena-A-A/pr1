﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;

namespace ConsoleApp4_3
{
  class Program
  {
    static void Main(string[] args)
    {
      XDocument xdoc = new XDocument();
      XElement XX5 = new XElement("avto");
      XAttribute ladaNameAttr = new XAttribute("name", "XX5");
      XElement ladaCompanyElem = new XElement("company", "Lada");
      XElement ladaPriceElem = new XElement("price", "40000");
      XX5.Add(ladaNameAttr);
      XX5.Add(ladaCompanyElem);
      XX5.Add(ladaPriceElem);
      XElement mi = new XElement("avto");
      XAttribute sheNameAttr = new XAttribute("name", "Mi");
      XElement sheCompanyElem = new XElement("company", "She");
      XElement shePriceElem = new XElement("price", "33000");
      mi.Add(sheNameAttr);
      mi.Add(sheCompanyElem);
      mi.Add(shePriceElem);
      XElement avtos = new XElement("avtos");
      avtos.Add(XX5);
      avtos.Add(mi);
      xdoc.Add(avtos);
      xdoc.Save("C:\\Users\\Luna\\source\\repos\\ConsoleApp4\\ConsoleApp4\\file.xml");

      XmlDocument xDoc = new XmlDocument();
      foreach (XElement phoneElement in xdoc.Element("avtos").Elements("avto"))
      {
        XAttribute nameAttribute = phoneElement.Attribute("name");
        XElement companyElement = phoneElement.Element("company");
        XElement priceElement = phoneElement.Element("price");

        if (nameAttribute != null && companyElement != null && priceElement != null)
        {
          Console.WriteLine($"Название: {nameAttribute.Value}");
          Console.WriteLine($"Компания: {companyElement.Value}");
          Console.WriteLine($"Цена: {priceElement.Value}");
        }
        Console.WriteLine();
      }
      int k = 0;
      while (k == 0)
      {
        Console.Write("Удалить файл? 1 -да, 0 - нет");
        string text2 = Console.ReadLine();
        if (text2 == "1")
        {
          File.Delete("C:\\Users\\Luna\\source\\repos\\ConsoleApp4\\ConsoleApp4\\file.xml");
          k++;
        }
        if (text2 == "0")
        {
          k++;
        }
        if (text2 != "1" && text2 != "0")
        {
          Console.WriteLine("Введен неправильный символ");
        }
      }
    }
  }
}
