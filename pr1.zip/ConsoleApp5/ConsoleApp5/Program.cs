﻿using System;
using System.IO;
using System.IO.Compression;

namespace ConsoleApp5
{
  class Program
  {
    static void Main(string[] args)
    {
      string sourceFile = "C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint.pptx"; 
      string compressedFile = "C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint.zip"; 
      string targetFile = "C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint_new.pptx"; 
      Compress(sourceFile, compressedFile);
      Decompress(compressedFile, targetFile);
      Console.ReadLine();
      int k = 0;
      while (k == 0)
      {
        Console.Write("Удалить файлы? 1 -да, 0 - нет");
        string text2 = Console.ReadLine();
        if (text2 == "1")
        {
          File.Delete(@"C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint.pptx");
          File.Delete(@"C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint.zip");
          File.Delete(@"C:\\Users\\Luna\\source\\repos\\ConsoleApp5\\MicrosoftPowerPoint_new.pptx");
          k++;
        }
        if (text2 == "0")
        {
          k++;
        }
        if (text2 != "1" && text2 != "0")
        {
          Console.WriteLine("Введен неправильный символ");
        }
      }
    }

    public static void Compress(string sourceFile, string compressedFile)
    {
      using (FileStream sourceStream = new FileStream(sourceFile, FileMode.OpenOrCreate))
      {
        using (FileStream targetStream = File.Create(compressedFile))
        {
          using (GZipStream compressionStream = new GZipStream(targetStream, CompressionMode.Compress))
          {
            sourceStream.CopyTo(compressionStream); 
            Console.WriteLine("Сжатие файла {0} завершено.\n Исходный размер: {1}\n  сжатый размер: {2}.",
                sourceFile, sourceStream.Length.ToString(), targetStream.Length.ToString());
          }
        }
      }
    }

    public static void Decompress(string compressedFile, string targetFile)
    {
      using (FileStream sourceStream = new FileStream(compressedFile, FileMode.OpenOrCreate))
      {
        using (FileStream targetStream = File.Create(targetFile))
        {
          using (GZipStream decompressionStream = new GZipStream(sourceStream, CompressionMode.Decompress))
          {
            decompressionStream.CopyTo(targetStream);
            Console.WriteLine("Восстановлен файл: {0}", targetFile);
          }
        }
      }
    }
  }
}



 

